import somepackage.Events;
class ClosedChannelExceptionTest
{
  void closeChannelBuffer()
  {
   		try{
   		ChannelBuffer bff = ChannelBuffers.buffer(18);
                  bff.writeByte(Events.S_SERVER_PUSH);  
                  bff.writeByte((byte)0);
                  bff.writeInt(idRoom);            
                  bff.writeInt(playerCnt);
                  bff.writeInt(gameCnt);
                  bff.writeInt(freePlayer);
                channel.write(bff);
                }catch(ClosedChannelException e){
                	//handle the exception
                }
  }

}