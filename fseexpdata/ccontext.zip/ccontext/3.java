package core;

class NumberFormatExceptionTest{
public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
		String val="120Student";
		int myval=Integer.parseInt(val);
		System.out.println(myval);
		}catch(NumberFormatException e)
		{
			//handle the exception
		}
	}
	}