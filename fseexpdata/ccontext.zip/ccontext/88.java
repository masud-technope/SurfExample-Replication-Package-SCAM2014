package core;
import java.awt.Font;
import java.awt.FontFormatException;
import java.io.InputStream;

public class RunnerTest {
 
    public static void main(String[] args){
        Font awtFont;  
        InputStream fontResource = Runner.class.getResourceAsStream("BitmapFont.fnt");
        try {
            awtFont = Font.createFont(Font.TRUETYPE_FONT, fontResource);
        } catch (Exception e) {
            e.printStackTrace();
            try{
                awtFont = Font.createFont(Font.TYPE1_FONT, fontResource);
            }catch (FontFormatException e1){
                //handle the exception
            }
        }
    }
 
}