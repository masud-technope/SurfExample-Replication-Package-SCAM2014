
package core;
import java.rmi.NotBoundException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

class NotBoundExceptionTest
{

public static void main(String[] args)
{

try {  
            Registry registry = LocateRegistry.getRegistry("ServerMc", 1099);  
            Services stub = (Services) registry.lookup("rmi://ServerMc:1099/Services");  
            String response = stub.sayHello();  
        } catch (NotBoundException e) {  
            //System.err.println("Client exception: " + e.toString());  
            //handle the exception  
        } 
     }
 }