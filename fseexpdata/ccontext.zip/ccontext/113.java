package core;   
import java.awt.image.BufferedImage;
import java.util.Iterator;

import javax.imageio.IIOException;
import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;

   class IIOExceptionTest
   {
   
   public static void main(String[] args)
   {
   try{
   Iterator readers = ImageIO.getImageReadersByFormatName("jpg");
   ImageReader reader = (ImageReader)readers.next();
   ImageInputStream iis = ImageIO.createImageInputStream(sourceFile);
   reader.setInput(iis,true,true);
   BufferedImage image = reader.read(0);
}catch(IIOException e){
	//handle the exception
}
}
}