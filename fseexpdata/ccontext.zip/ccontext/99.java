package core;

import java.io.File;
import java.io.FileInputStream;

import javax.script.ScriptException;

class ScriptExceptionTest
{
void onStart() throws IOException {
    String location = DatabaseDescriptor.getCalloutLocation();
    if (location == null) return;
    File directory = new File(location);
    if (!directory.exists()) directory.mkdir();
    File[] files = directory.listFiles();
    for (File file : files) {
        String f = file.getName();
        String callout = f.split(extn_)[0];
        FileInputStream fis = new FileInputStream(file);
        byte[] bytes = new byte[fis.available()];
        fis.read(bytes);
        fis.close();
        try {
            compileAndCache(callout, new String(bytes));
        } catch (ScriptException ex) {
            //handle the exception
        }
    }
   }
 }