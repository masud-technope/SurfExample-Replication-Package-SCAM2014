package core;

import java.awt.event.KeyEvent;
import java.lang.Character;

class BadLocationExceptiontTest {
	// this is my keyReleased method
	public void keyReleased(KeyEvent arg0) {
		char character = arg0.getKeyChar();
		if (wordStarted) { // have I started typing a new word ?
			if (character == ' ') { // end word
				try {
					int dot = getCaret().getDot();
					highlight(wordStart, dot - 1);
					setCaretPosition(dot);
					wordStarted = false;
				} catch (BadLocationException ex) {
					//handle the exception
				}
			}
		} else {
			if (Character.isLetter(character)) {
				wordStarted = true;
				wordStart = getCaret().getDot() - 1;
			}
		}
	}
}