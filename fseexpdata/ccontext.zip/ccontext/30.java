package core;

import java.io.InputStream;
import java.io.StringBufferInputStream;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Element;
import org.xml.sax.SAXParseException;

class SAXParseExceptionTest {
	public static void main(String[] args) {
		try {
			String s = "Hello DOM Parser";
			@SuppressWarnings("deprecation")
			InputStream sbis = new StringBufferInputStream(s);
			DocumentBuilderFactory b = DocumentBuilderFactory.newInstance();
			b.setNamespaceAware(false);
			Document doc = null;
			DocumentBuilder db = null;
			db = b.newDocumentBuilder();
			doc = db.parse(sbis);
			Element e = doc.getDocumentElement();
		} catch (SAXParseException e) {
			//handle the exception
		}
	}
}