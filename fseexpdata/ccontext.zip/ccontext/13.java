import java.awt.Dimension;

import java.awt.HeadlessException;

import java.awt.event.ActionListener;

import java.io.BufferedReader;

import java.io.File;

import java.io.FileInputStream;

import java.io.IOException;

import java.io.InputStream;

import java.io.InputStreamReader;

import java.lang.reflect.InvocationTargetException;

import java.net.InetAddress;

import java.net.URL;

import java.net.UnknownHostException;

import java.util.Enumeration;

import java.util.Hashtable;

import java.util.LinkedHashMap;

import java.util.List;

import java.util.Locale;

import java.util.MissingResourceException;

import java.util.Properties;

import java.util.Random;

import java.util.ResourceBundle;

import java.util.Vector;

import javax.swing.ImageIcon;

import javax.swing.JButton;

import javax.swing.JComboBox;

import javax.swing.JOptionPane;

import javax.swing.SwingUtilities;

import org.apache.commons.io.IOUtils;

import org.apache.jmeter.gui.GuiPackage;

import org.apache.jorphan.logging.LoggingManager;

import org.apache.jorphan.reflect.ClassFinder;

import org.apache.jorphan.test.UnitTestManager;

import org.apache.jorphan.util.JOrphanUtils;

import org.apache.log.Logger;

import org.apache.oro.text.MalformedCachePatternException;

import org.apache.oro.text.PatternCacheLRU;

import org.apache.oro.text.regex.Pattern;

import org.apache.oro.text.regex.Perl5Compiler;

import org.apache.oro.text.regex.Perl5Matcher;

import org.xml.sax.XMLReader;



class InstantiationExceptionDemo {

private static final Logger log = LoggingManager.getLoggerForClass();
public static final PatternCacheLRU INSTANCE;
private static volatile Properties appProperties;
private static final Vector<LocaleChangeListener> localeChangeListeners;
private static volatile Locale locale;
private static volatile ResourceBundle resources;
private static final Random rand = new Random();

     //static JTextField field = new JTextField();// works if uncommented
public static Object instantiate(String className, String impls) {
    if (className != null) {
        className = className.trim();
    }
    if (impls != null) {
        impls = impls.trim();
    }
    try {
        Class<?> c = Class.forName(impls);
        try {
            Class<?> o = Class.forName(className);
            Object res = o.newInstance();
            if (c.isInstance(res)) {
                return res;
            }
            throw new IllegalArgumentException(className + " is not an instance of " + impls);
        } catch (ClassNotFoundException e) {
            //handle the exception
        } catch (IllegalAccessException e) {
            //handle the exception
        } catch (InstantiationException e) {
            //handle the exception
        } catch (NoClassDefFoundError e) {
            //handle the exception
        }
    } catch (ClassNotFoundException e) {
        //handle the exception
    }
    return null;
}
}