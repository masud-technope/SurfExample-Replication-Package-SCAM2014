import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.image.BufferedImage;
import javax.imageio.IIOException;
import javax.swing.ImageIcon;

class IIOExceptionTest
{

public static void main(String[] args)
{
	try{
	Robot robot = new Robot();
        Dimension screenSize  = Toolkit.getDefaultToolkit().getScreenSize();
        Rectangle screen = new Rectangle( screenSize );
        BufferedImage i = robot.createScreenCapture( screen );
 
        // ----- start of changes from workaround -----
        // Work around a Sun bug that causes a hang in "sun.awt.image.ImageRepresentation.reconstruct".
        new ImageIcon(i); // Force load.
        BufferedImage newImage = new BufferedImage(i.getWidth(null), i.getHeight(null), BufferedImage.TYPE_INT_ARGB);
        newImage.createGraphics().drawImage(i, 0, 0, null);
        i = newImage;
        // ----- end of changes from workaround -----
 
        TransferableImage trans = new TransferableImage( i );
        Clipboard c = Toolkit.getDefaultToolkit().getSystemClipboard();
        c.setContents( trans, this );
        }catch(IIOException e){
        	//handle the exception
        }
    }
   }