package core;
import java.io.EOFException;
import java.util.Map;

class EOFExceptionTest
{

public static void main(String[] args)
{
Map<String, String> conv = null;
Type type = new TypeToken<Map<String, String>>(){}.getType();
ListMultimap<String, Object> returnMap = ArrayListMultimap.create();    
    try {
        conv = g.fromJson(parse, type);
        for(String key : conv.keySet()) {
           returnMap.put("Key", key);
           returnMap.put("Value", conv.get(key));
        }
    } catch (JsonSyntaxException jse) {
        type = new TypeToken<Map<String, Object>>(){}.getType();
        conv = g.fromJson(parse, type);
        for(Object key : conv.keySet()) {
           returnMap.put("Key", key);
           returnMap.put("Value", conv.get(key));
        }
    }catch(EOFException e){
    //handle the exception
    }
} 
}