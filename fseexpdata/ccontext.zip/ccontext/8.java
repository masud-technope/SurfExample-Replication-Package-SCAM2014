package core;
import somepackage.HttpClient;
class IllegalArgumentExceptionTest{

 public String getHttpConnectionToServer(String uri, String proxyIP,
               Integer port, String debugMode) {

    try{
    HttpGet httppost = new HttpGet(uri);
    HttpResponse response = client.execute(httppost);
    HttpEntity entity = response.getEntity();
    InputStream is = entity.getContent();
    BufferedReader reader = new BufferedReader(new InputStreamReader(
        is, "iso-8859-1"), 8);
    StringBuilder sb = new StringBuilder();
    }catch(IllegalArgumentException ex){
    	//handle exception
    }
}
}