import  java.sql.Date;

class IllegalStateExceptionTest{

public MyDTO process(MyDTO data) throws Exception {
    try{
    // do some stuff to data
    Date myDate = myCollaborator.getCurrentApplyDate();
    // do some stuff with myDate and data
    String currentBatch = myCollaborator.getCurrentBatch();
    // do some other stuff with currentBatch and data
    }catch(IllegalStateException e){
    	//handle the exception
    }
    return data;
   }
}