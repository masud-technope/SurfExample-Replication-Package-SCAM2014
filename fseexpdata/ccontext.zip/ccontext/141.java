package core;

import java.awt.Image;

class SWTExceptionTest
{
	public static void main(String[] args) {
	    try{
		Display display = new Display();
	    Shell shell = new Shell(display);
	
	    Image image = new Image(display,
	       "D:/topic.png");
	    GC gc = new GC(image);
	    gc.setForeground(display.getSystemColor(SWT.COLOR_WHITE));
	    gc.drawText("I've been drawn on",0,0,true);
	    gc.dispose(); 
	
	    shell.pack();
	    shell.open();
	
	    while (!shell.isDisposed()) {
	        if (!display.readAndDispatch()) {
	            display.sleep();
	        }
	    }
	    display.dispose();
	    // TODO Auto-generated method stub
	    }catch(SWTException e){
	    	//handle the exception
	    }
	}

}