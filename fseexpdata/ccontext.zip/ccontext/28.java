package core;
import java.io.File;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.net.UnknownServiceException;

class UnknownServiceExceptionTest {

	public static void main(String[] args) {
		try {
			URL url = new File("test.txt").toURL();
			URLConnection connection = url.openConnection();
			connection.setDoOutput(true);
			OutputStream output = connection.getOutputStream();
		} catch (UnknownServiceException e) {
			// handle the exception
		}
	}
}