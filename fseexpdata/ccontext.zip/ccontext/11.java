package core;

import java.util.InputMismatchException;
import java.util.Scanner;

class InputMismatchExceptionTest {
	public static void main(String[] args)

	{
		try {
			int age;
			int name;

			Scanner scan = new Scanner(System.in);

			System.out.println("Enter in your age.");
			age = scan.nextInt();

			if (age < 18)

			{
				System.out.println("So you're a kid, huh? That's fine.");
			}

			else if (age >= 18)

			{
				System.out.println("Ah, and adult! Good.");
			}

			@SuppressWarnings("resource")
			Scanner in = new Scanner(System.in);

			System.out.println("Enter in your name");
			name = in.nextInt();

			System.out.println("So you're " + age
					+ " years old and your name is " + name);
		} catch (InputMismatchException exc) {
			//handle the exception
		}

	}
}