package core;
class CloneNotSupportedExceptionTest {
	public static void main(String[] args) throws CloneNotSupportedException {
		try {
			Address address = new Address("?????????", "1234567", 20);
			Student stu = new Student("????", 20);
			stu.setAddress(address);

			Student stu2 = (Student) stu.clone();
			stu2.setAddress(new Address("???????", "484848348", 22));

			stu2.setName("???");
			stu2.setAge(23);
			stu.sayHi();
			stu2.sayHi();
		} catch (CloneNotSupportedException e) {
			//handle the exception
		}
	}
}