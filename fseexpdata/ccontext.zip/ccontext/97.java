package core;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.net.ProtocolException;
import java.net.URLConnection;

  class ProtocolExceptionTest
  {
  public static void main(String[] args)
  {
 	 URLConnection conn;
 	 try {
            BufferedInputStream  bis = new BufferedInputStream(conn.getInputStream());  
            BufferedOutputStream bos = new BufferedOutputStream(response.getOutputStream());
            byte[] buff = new byte[2048];
            int bytesRead;
            
            while (-1 != (bytesRead = bis.read(buff, 0, buff.length))) {
                bos.write(buff, 0, bytesRead);
            }
            bos.flush();
            } catch (IOException e) {
                   log.error("error getting inputstream from connection");
             }catch(ProtocolException exc){
            	 //handle the exception
             }
      }
      }