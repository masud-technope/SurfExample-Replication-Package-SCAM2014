package core;

import java.lang.reflect.UndeclaredThrowableException;
import java.util.Iterator;
import java.util.List;
import somepackage.Article;

 public class UndeclaredThrowableExceptionTest {
     ArtilceProvider epicerie;
     public void lister(){
     try{
         List<Article> arr=epicerie.listerLesArticles();
         System.out.println(" ");
         Iterator<Article> iterator =  arr.iterator();
         while (iterator.hasNext()) {
             Article unArticle=iterator.next();
             System.out.println(unArticle.getCode());
         }
         System.exit(0);
         }catch(UndeclaredThrowableException e){
        	 //handle the exception
         }
}
}