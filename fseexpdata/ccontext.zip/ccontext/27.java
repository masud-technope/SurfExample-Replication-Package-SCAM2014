package core;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.UnknownHostException;

class UnknownHostExceptionTest {
	public static void main(String[] args) {
		try {
			long startTime = System.currentTimeMillis();

			String source = "s";
			String source1 = "s";
			URL google = new URL("http://google.com/");
			HttpURLConnection yc = (HttpURLConnection) google.openConnection();
			BufferedReader in = new BufferedReader(new InputStreamReader(
					yc.getInputStream()));
			String inputLine;
			while ((inputLine = in.readLine()) != null) {
				source = source.concat(inputLine);
			}
			in.close();
			yc.disconnect();
		} catch (UnknownHostException e) {
			//handle the exception
		}
	}
}