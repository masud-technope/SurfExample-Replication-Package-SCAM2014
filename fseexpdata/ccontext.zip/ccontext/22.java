package core;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

class ParseExceptionTest
{
public static void main(String[] args){
try{
	 String date="Sat Jun 01 12:53:10 IST 2013";
	    SimpleDateFormat sdf=new SimpleDateFormat("MMM d, yyyy HH:mm:ss");
	    Date currentdate;
	    currentdate=sdf.parse(date);
    	    System.out.println(currentdate);
    	    }catch(ParseException e){
    	    	//handle the exception
    	    }
}}		