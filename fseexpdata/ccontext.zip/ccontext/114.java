package core;
import java.io.IOException;
import javax.imageio.IIOException;
import Locale;
import ImageWriteParam;

class IIOExceptionTest
{

public static void main(String[] args)
{
		TIFFImageWriteParam writeParam = new TIFFImageWriteParam(Locale.ENGLISH);
            writeParam.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
            try{
                if(writer.canReplacePixels(0)){ // LINE 90
                    System.out.println("True");
                }else{
                    System.out.println("False");
                }
            }catch(IIOException e){
            	//handle the exception
            }
            catch (IOException e) {
                e.printStackTrace();
            }
   }
 }