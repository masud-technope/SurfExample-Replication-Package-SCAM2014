package core;

import java.security.cert.CertificateException;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

class CertificateExceptionTest {
	public static void main(String[] args) {
		try {
			HttpsURLConnection
					.setDefaultHostnameVerifier(new HostnameVerifier() {
						public boolean verify(String hostname,
								SSLSession sslSession) {
							if (hostname.equals("localhost")) {
								return true;
							}
							return false;
						}
					});
		} catch (CertificateException e) {
			//handle the exception
		}
	}
}