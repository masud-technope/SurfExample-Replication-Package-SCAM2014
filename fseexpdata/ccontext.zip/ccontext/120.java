package core;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.ObjectInputStream;

public class StudentArrayObjectFileReader {
public static void main(String[] args) {
    try {
        ObjectInputStream fileReader = new ObjectInputStream(new FileInputStream("students_updated.dat"));
        Student[] studs = (Student[]) fileReader.readObject();
        fileReader.close();
        // List the records in console
        for (int i = 0; i < studs.length; i++) {
            System.out.printf("%7d %-35s %-5s %1d %-6s%n",studs[i].getID(), studs[i].getName(), studs[i].getCourse(), studs[i].getYr(), studs[i].getGender());
        }
    } catch (FileNotFoundException fnfe) {
        fnfe.printStackTrace();
    } catch (Exception e) {
        e.printStackTrace();
    }catch(EOFException e){
    	//handle the exception
    }
 }
}


     