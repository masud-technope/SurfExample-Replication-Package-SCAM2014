package core;

import javax.imageio.ImageIO;
import java.awt.AWTException;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

class FileNotFoundExceptionTest {

	public static void main(String[] args) throws IOException, AWTException {
		try {
			String imageFile = StaticData.Dataset_home
					+ "/ExceptionDocs/-Files/awtexception.png";
			Robot robot = new Robot();
			BufferedImage buffredImage = robot
					.createScreenCapture(new Rectangle(500, 500));
			ImageIO.write(buffredImage, "png", new File(imageFile));
			System.out.println("Screenshot saved successfully!");
		} catch (FileNotFoundException exc) {
			// handle the exception
		}
	}
}
