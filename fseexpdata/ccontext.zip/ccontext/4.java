package core;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import somepackage.Record;

class EOFExceptionTest{
public void HighScores() throws IOException, ClassNotFoundException 
{  
        try {  
            File file=new File("filename.txt");
            FileInputStream fis = new FileInputStream(file);  
            ObjectInputStream ois = new ObjectInputStream(fis);  
            ArrayList<Record> currentList = new ArrayList<Record>();  
            //restore the number of objects  
            int size = ois.readInt();  
            for (int i=0; i<size; i++) {  
                Record current = (Record) ois.readObject();  
                currentList.add(current);  
            }  
            //          Record current;  
            //          while ((current = (Record) ois.readObject()) != null) {  
            //              currentList.add(current);  
            //          } 
            }
            catch(EOFException exc){
            	//handle the exception
            }
        }  
  }