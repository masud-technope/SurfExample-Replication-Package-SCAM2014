package core;

import java.io.EOFException;
import javax.xml.validation.Schema;

class EOFExceptionTest {

	public static void main(String[] args) {
		try {
			String schemaJson = "paste schema here (and fix quotes)";
			Schema schema = Schema.parse(schemaJson);
			GenericRecord datum = new GenericData.Record(schema);
			GenericRecord result = dataFileReader.next();
			System.out.println("data" + result.get("left").toString());
			result = dataFileReader.next();
			System.out.println("data :" + result.get("left").toString());

		} catch (EOFException ex) {
			//handle the exception
		}

	}
}