package core;
import java.util.NoSuchElementException;
import java.util.Scanner;


class NoSuchElementExceptionTest
{
    public static void main(String[] args){
    try{
    Scanner input = new Scanner( System.in );
    int number1; // first number to add
    int number2; // second number to add
    int sum; // sum of 1 & 2

    System.out.print ("Enter First Integer: " ); // prompt
    number1 = input.nextInt(); // reads first number inputted by user

    System.out.print ("Enter Second Integer: "); // prompt 2 
    number2 = input.nextInt(); // reads second number from user

    sum = number1 + number2; // addition takes place, then stores the total of the two numbers in sum

    System.out.printf( "Sum is %d\n", sum ); // displays the sum on screen
    }catch(NoSuchElementException e){
    	//handle the exception
    }
    }
}