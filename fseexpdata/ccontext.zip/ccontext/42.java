import java.io.*;

import java.net.URI;

import java.util.*;

import org.apache.hadoop.conf.Configuration;

import org.apache.hadoop.conf.Configured;

import org.apache.hadoop.io.BytesWritable;

import org.apache.hadoop.io.IntWritable;

import org.apache.hadoop.io.SequenceFile;

import org.apache.hadoop.io.Text;

import org.apache.hadoop.io.Writable;

import org.apache.hadoop.io.WritableComparable;

import org.apache.hadoop.io.WritableComparator;

import org.apache.hadoop.io.WritableUtils;

import org.apache.hadoop.mapred.lib.HashPartitioner;

import org.apache.hadoop.util.Tool;

import org.apache.hadoop.util.ToolRunner;

import org.apache.hadoop.fs.*;

class ArrayIndexOutOfBoundsExceptionTest
 {
 
 private static final IntWritable sortInput;
 private static final IntWritable sortOutput;
 private static final PathFilter sortPathsFilter;
 private IntWritable key = null;
 private WritableComparable prevKey = null;
 private Class<? extends WritableComparable> keyClass;
 private Partitioner<WritableComparable, Writable> partitioner = null;
 private int partition = -1;
 private int noSortReducers = -1;
 private long recordId = -1;
 private Raw rawKey;
 private Raw rawValue;
 private IntWritable value = null;
 
 public int run(String[] args) throws Exception {
     Configuration defaults = getConf();
     int noMaps = -1, noReduces = -1;
     Path sortInput = null, sortOutput = null;
     boolean deepTest = false;
     for (int i = 0; i < args.length; ++i) {
         try {
             if ("-m".equals(args[i])) {
                 noMaps = Integer.parseInt(args[++i]);
             } else if ("-r".equals(args[i])) {
                 noReduces = Integer.parseInt(args[++i]);
             } else if ("-sortInput".equals(args[i])) {
                 sortInput = new Path(args[++i]);
             } else if ("-sortOutput".equals(args[i])) {
                 sortOutput = new Path(args[++i]);
             } else if ("-deep".equals(args[i])) {
                 deepTest = true;
             } else {
                 printUsage();
                 return -1;
             }
         } catch (NumberFormatException except) {
             //handle the exception
         } catch (ArrayIndexOutOfBoundsException except) {
             //handle the exception
         }
     }
     if (sortInput == null || sortOutput == null) {
         printUsage();
         return -2;
     }
     RecordStatsChecker.checkRecords(defaults, sortInput, sortOutput);
     if (deepTest) {
         RecordChecker.checkRecords(defaults, noMaps, noReduces, sortInput, sortOutput);
     }
     System.out.println("\nSUCCESS! Validated the MapReduce framework's 'sort'" + " successfully.");
     return 0;
}
   }