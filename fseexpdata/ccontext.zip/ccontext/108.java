package core;

import java.awt.PrintJob;
import java.awt.print.PrinterException;
import javax.print.attribute.PrintRequestAttributeSet;
import somepackage.HashPrintRequestAttributeSet;
import somepackage.OrientationRequested;
import somepackage.MediaSizeName;

class PrinterExceptionTest {
	public static void main(String[] args) {
		PrintJob job;
		try {
			PrintRequestAttributeSet aset = new HashPrintRequestAttributeSet();
			aset.add(OrientationRequested.PORTRAIT);
			aset.add(MediaSizeName.INVOICE);
			job.print(aset);
		} catch (PrinterException e) {
			//handle the exception
		}
	}
}