package core;
import javax.swing.JOptionPane;
import somepackage.Manager;

class ConnectExceptionTest {
	JTextField idField;
	JPasswordField passField;
	Socket c;

	private void submit() throws ConnectException {

		String id = idField.getText();
		char[] pass1 = passField.getPassword();
		String pass = new String(pass1);
		if (id.equals("") || pass.equals("")) {
			JOptionPane.showMessageDialog(this,
					"You should enter an ID and password", "Sign_In Problem",
					JOptionPane.OK_OPTION);
			return;
		} else {
			boolean b = Manager.Test(id, pass);
			if (b == true) {
				this.setVisible(false);

				try {
					c = new Socket("localhost", 5000);
				} catch (ConnectException ex) {
					//handle the exception
				} catch (IOException ex) {
					
				}

				ListFrame frame = new ListFrame(client);
				frame.setVisible(true);
			} else {
				JOptionPane.showMessageDialog(this,
						"You have entered wrong datas,try it again",
						"Sign_In Problem", JOptionPane.OK_OPTION);
				return;
			}
		}
	}
}
