package core;

import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;
import java.security.AccessControlException;

class AccessControlExceptionTest
{
public static void main(String[] args){
try
		{
		LocateRegistry.createRegistry(1098);
		System.out.println("RMI Registry setup successfully.");
		}catch(Exception exc){
			System.err.println(exc.getMessage());
		}
		catch(AccessControlException e){
			//handle the exception
		}
		MathServiceProvider provider=new MathServiceProvider();
		Naming.bind("MathService", provider);
		System.out.println("Service is bound to RMI registry");
	}
}