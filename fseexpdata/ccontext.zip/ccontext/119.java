package core;

class EOFExceptionTest {
	public static void main(String[] args) {
		try {
			ConnectionConfiguration connConfig = new ConnectionConfiguration(
					"talk.google.com", 5222, "gmail.com");
			XMPPConnection connection = new XMPPConnection(connConfig);
			connection.connect();
			System.in.read();
			connection.login("xxx@gmail.com", "***"); // Exception occurs here!
		} catch (SocketException e) {
			//handle the exception
		}
	}
}