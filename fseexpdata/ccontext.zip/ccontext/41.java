package core;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.UTFDataFormatException;
import java.util.ArrayList;

class UTFDataFormatExceptionTest {
	public static void main(String args[]) {
		try {

			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			DataOutputStream byteOut = new DataOutputStream(baos);
			ArrayList stringArray;
			byte[] data = stringArray.get(i).getBytes("UTF-8");
			byteOut.writeUTF(stringArray.get(i));
			byteOut.close();
			byte[] input = baos.toByteArray();
		} catch (UTFDataFormatException e) {
			//handle the exception
		}
	}
}