package core;

import java.io.InputStream;
import java.io.InputStreamReader;

import javax.swing.text.ChangedCharSetException;
import javax.swing.text.html.HTMLEditorKit.ParserCallback;
import javax.swing.text.html.parser.ParserDelegator;

class ChangedCharSetExceptionTest {

	public static void main(String[] args) {
		try {
			InputStream inputStream;
			InputStreamReader inputStreamReader;
			inputStream = rsc.getUrl().openStream();
			inputStreamReader = new InputStreamReader(inputStream);
			ParserDelegator parserDelegator = new ParserDelegator();
			ParserCallback parserCallback = new ParserCallback() {
				public void handleStartTag(Tag tag,
						MutableAttributeSet attribute, int pos) {
					if (tag == Tag.A) {
						String address = (String) attribute
								.getAttribute(Attribute.HREF);
						if ((address != null)
								&& !address.equalsIgnoreCase("null"))
							links.add(address);
					}
				}

				public void handleSimpleTag(Tag t, MutableAttributeSet a,
						final int pos) {
				}

				public void handleEndTag(Tag t, final int pos) {
				}

				public void handleComment(final char[] data, final int pos) {
				}

				public void handleText(final char[] data, final int pos) {
				}

				public void handleError(final java.lang.String errMsg,
						final int pos) {
				}
			};
			parserDelegator.parse(inputStreamReader, parserCallback, false);
		} catch (ChangedCharSetException e) {
			//handle the exception
		}
	}
}