package core;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.Set;
import java.util.HashSet;

class IllegalAccessExceptionTest {
	public static void main(String[] args) {

		try {
			Set<String> myStr = new HashSet<String>();
			myStr.add("obj1");
			Iterator itr = myStr.iterator();
			Method mtd = itr.getClass().getMethod("hasNext");
			System.out.println(mtd.invoke(itr, args));
		} catch (IllegalAccessException exc) {
			//handle the exception
		}
	}
}