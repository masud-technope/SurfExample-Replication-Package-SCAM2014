package core;
public class InstantiationExceptionTest {
	public static void main(String[] args) throws InstantiationException,
			IllegalAccessException {
		try {
			String a = "s";
			String newInstance = a.getClass().newInstance();
			System.out.println(newInstance);
			Double b = 0d;
			Double newInstance2 = b.getClass().newInstance();
			System.out.println(newInstance2);
		} catch (InstantiationException e) {
			//handle the exception
		}
	}
}