package core;
import java.lang.Class;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

class ClassNotFoundExceptionTest
{
public static void main(String[] args)
{

try
		{
		//code for making connection with a sqlite database
			Class.forName("org.sqlite.JDBC");
			Connection connection=null;
			connection=DriverManager.getConnection("jdbc:sqlite:"+"/"+"test.db");
			Statement statement=connection.createStatement();
			String create_query="create table History ( LinkID INTEGER primary key, Title TEXT not null, LinkURL TEXT not null);";
			boolean created=statement.execute(create_query);
			System.out.println("Succeeded");
		}catch(ClassNotFoundException exc){
			//handle the exception
		}
	}
}