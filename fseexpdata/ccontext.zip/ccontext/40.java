package core;

import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;

class ProtocolExceptionTest
{

public static void main(String[] args)
{

    try{
    URL url = new URL("http://www.palringo.com/en/gb/");        
    HttpURLConnection.setFollowRedirects(false);
    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
    // Just for testing, use Chrome header, to eliminate "anti-crawler" response!
    connection.setRequestProperty("User-Agent", "Mozilla/5.0 (X11; Linux i686) AppleWebKit/534.30 (KHTML, like Gecko) Ubuntu/11.04 Chromium/12.0.742.112 Chrome/12.0.742.112 Safari/534.30");
    System.out.println("Response code = " + connection.getResponseCode());
    }catch(ProtocolException e){
    	//handle the exception
    }
   }
}