package core;

import java.net.BindException;
import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;

class BindExceptionTest {

	public static void main(String[] args) {
		try {
			LocateRegistry.createRegistry(1099);
			System.out.println("RMI Registry setup successfully.");
			MathServiceProvider provider = new MathServiceProvider();
			Naming.bind("MathService", provider);
			System.out.println("Service is bound to RMI registry");
		} catch (BindException exc) {
			//handle the exception
		}

	}
}