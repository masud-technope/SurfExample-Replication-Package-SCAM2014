package core;

import java.io.FileInputStream;
import java.io.IOException;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;

class SOAPExceptionTest {
	public SOAPMessage createSOAPMessageFromFile() throws SOAPException,
			IOException {
		SOAPMessageFactory mSOAPMsgFactory;
		try {
			FileInputStream theFIS = new FileInputStream(SOAP_FILE);
			MimeHeaders theMimeHdrs = new MimeHeaders();
			SOAPMessage theMsg = mSOAPMsgFactory.createMessage(theMimeHdrs,
					theFIS);
			theFIS.close();

			SOAPBody theBody = theMsg.getSOAPBody();
			SOAPHeader theHeader = theMsg.getSOAPHeader();

			System.out.println("Retrieving parts of SOAP message:");
			System.out.println(" The SOAP body: " + theBody);
			System.out.println(" The SOAP header: " + theHeader);
		} catch (SOAPException e) {
			//handle the exception
		}

		return theMsg;
	}

}