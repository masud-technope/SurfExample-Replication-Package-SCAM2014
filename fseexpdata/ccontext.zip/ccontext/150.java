package core;
import java.io.InputStream;
import java.util.zip.ZipException;

class ZipExceptionTest
{

public static void main(String[] args)
{
     
    FTPClient ftp = new FTPClient();
    ftp.connect("ftp.ncbi.nih.gov");
    ftp.login("anonymous", "");
    InputStream is = null;  
    try {
 	is=new GZIPInputStream(ftp.retrieveFileStream("/genbank/gbbct1.seq.gz"));
        byte[] buffer = new byte[65536];
        int noRead;
 
        while ((noRead = is.read(buffer)) != 1) {
            System.out.write(buffer, 0, noRead);
        }
    }catch(ZipException e){
    	//handle the exception
    } 
    finally {
        is.close();
        ftp.disconnect();
     }
   }
}
 