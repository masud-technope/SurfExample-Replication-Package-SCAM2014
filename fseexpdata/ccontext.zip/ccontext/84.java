package core;

import java.lang.Class;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

class InvocationTargetExceptionTest {

	public static void main(String[] args) {

		// Retrieve an instance of the current class as an Object.
		Class<?> c = Class.forName("main.java.ReflectionExample");
		Object t = c.newInstance();
		Method[] declaredMethods = c.getDeclaredMethods();
		for (Method method : declaredMethods) {
			String methodName = method.getName();

			// Skip the current main method.
			if (methodName.contains("main"))
				continue;

			System.out.format("Invoking %s()%n", methodName);
			try {
				// Declare the method as accessible.
				method.setAccessible(true);
				/*
				 * Invoke the method with a 'null' parameter value, in order for
				 * an exception to be thrown.
				 */
				Object returnValue = method.invoke(t, "");

				System.out.format("%s() returned: %d%n", methodName,
						returnValue);
			} catch (InvocationTargetException ex) {
				// handle the exception
			}
		}
	}
}