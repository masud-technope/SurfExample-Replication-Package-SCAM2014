package core;
import java.net.InetSocketAddress;
import java.nio.channels.ClosedChannelException;
import java.util.logging.Logger;

import somepackage.SocketChannel;

class ClosedChannelExceptionTest
{
	Logger logger;
	private synchronized boolean verifyConnection() {
	    SocketChannel sc = SocketChannel.open();
	        sc.socket().setKeepAlive(true);
    		sc.socket().setSoTimeout(30000);
	    
	    if (sc.isConnected()) {
	        return true;
	    }
	    try {
	        if (!sc.isOpen()) {
	            logger.info("Channel WebBroker->CC is CLOSED unexpectedly. Opening new channel " + getIpAddress() + ":" + getIpPort() + "");
	            openChannel();
	        }
	        sc.socket().close();
	        sc.connect(new InetSocketAddress(getIpAddress(), getIpPort()));
	        while(!sc.finishConnect()){
	            Thread.sleep(1);    
	        }
	        logger.info("Connection established " + getIpAddress() + ":" + getIpPort());
	        sc.socket().setKeepAlive(true);
	        return sc.isConnected();
	    } catch (ClosedChannelException e) {
	        //handle the exception
	    }
	}
       }