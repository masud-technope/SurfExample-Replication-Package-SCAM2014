package core;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

class InterruptedExceptionTest
{
 
HTMLGenerator htmlGen;
 protected void doInBackground() throws Exception {
    try{
        String value="";
        URL historyURL = new URL("http://127.0.0.1:8080/"+dbName+id+"?value");
        URLConnection hc = historyURL.openConnection();    
        BufferedReader in = new BufferedReader(new InputStreamReader(hc.getInputStream()));  
        String line;
        while ((line = in.readLine()) != null) {
            value+=line;
        }
        in.close();
        this.htmlGen.formDisplayerHead();
        this.htmlGen.formNodeDataHtml(value,this.versionsData);
        this.htmlGen.formDisplayerTail();
    }  
    catch(InterruptedException e)
    {
        //handle the exception
    }
        return null;
}
}