package core;
import XMLOutputFactory;
import XMLEventFactory;

class XMLStreamExceptionTest {

private void initNewXMLDocument() throws ParserConfigurationException, FileNotFoundException, XMLStreamException {
 
       try{
        XMLOutputFactory outputFactory = XMLOutputFactory.newInstance();
        XMLEventWriter eventWriter = outputFactory.createXMLEventWriter(new FileOutputStream(path));
        XMLEventFactory eventFactory = XMLEventFactory.newInstance();
        end = eventFactory.createDTD("n");
        tab = eventFactory.createDTD("t");
 
        StartDocument startDocument = eventFactory.createStartDocument("UTF-8");
        eventWriter.add(startDocument);
        addLineBreakWithTabs(true, 0); // still works
 
        StartElement configStartElement = eventFactory.createStartElement("", "", DATA);
        eventWriter.add(configStartElement);
        addLineBreakWithTabs(true, 1); // throws exception, why?
        }
        catch(XMLStreamException e)
        {
        	//handle the exception
        }
    }  
}